WHYRO LAUNCH PACKAGE
====================

Files
-----
index.html   The WHYRO website.
robots.txt   Allows search engines to crawl public pages and points to the sitemap.
sitemap.xml  Basic sitemap for the homepage.

IMPORTANT
---------
whyro.com is your intended domain, not a verified or purchased domain.
If you use a different domain, replace every occurrence of https://whyro.com in
robots.txt and sitemap.xml with the actual HTTPS domain before publishing.

LOW-COST PUBLISHING PLAN (Cloudflare Pages)
-------------------------------------------
1. Check whether your desired domain is available at a registrar before paying.
   ICANN lookup: https://lookup.icann.org/
2. Create a Cloudflare account: https://dash.cloudflare.com/
3. Open Workers & Pages, create a Pages project, and use the direct-upload option
   if available in your dashboard. Upload the site files (or a ZIP of the files).
4. Confirm the temporary *.pages.dev URL opens correctly.
5. If you buy the domain, add it in your Pages project's Custom domains section.
   For an apex domain such as whyro.com, follow Cloudflare's nameserver/DNS prompts.
   Do not copy DNS records from random tutorials; follow the values shown in your
   own dashboard.
6. Wait for DNS and HTTPS provisioning to finish, then test both the root domain
   and www version if you configure both.
7. In Google Search Console (https://search.google.com/search-console/), add and
   verify your domain. Submit https://YOUR-DOMAIN/sitemap.xml and use URL Inspection
   to request crawling of the homepage.

SEARCH ENGINE EXPECTATIONS
--------------------------
A sitemap helps discovery but does not guarantee indexing or a top search ranking.
Google can take days or weeks to crawl a new site. Useful original content and links
from relevant sites can help people and search engines discover WHYRO.

IMPORTANT PLATFORM LIMITATIONS
------------------------------
This package publishes the public front-end only. The member/project/journal editing
controls in this prototype save to the current browser, not a shared database.
Do not use them as the official source of team records.

A full platform still needs:
- Authentication and roles for members/admins
- Shared database for profiles, projects, and research notes
- File storage with access permissions and backups
- GitHub integration or Git-based repositories for source code
- Server-side email provider for application and outreach delivery
- Privacy policy, terms, and security review before accepting real member data

Keep private research and personal data out of this public static website until the
backend and permissions are implemented.
